## Summary of Runs for "tbench-task"
### Difficulty: medium
| Agent/Model | # of total runs | # of successes | # of failures<br>(agent timeout) | # of failures<br>(other reasons) | Accuracy |
|-------------|-----------------|-----------------|------------------------------------|---------------|----------|
| nop | 1 | 0 | 0 | 1 | 0.0 |
| oracle | 3 | 3 | 0 | 0 | 1.0 |
| terminus-gpt5-5 | 5 | 3 | 0 | 2 | 0.6 |
| terminus-claude-opus-4-8 | 5 | 4 | 0 | 1 | 0.8 |
<details>
<summary>Tests Result</summary>

✅ This task is solvable by the agents.
| Test Name | Successful Runs / Total Runs |
|-------------|------------------------------|
| milestone_1 → TestMilestone1 → test_output_exists | 10 / 10 |
| milestone_1 → TestMilestone1 → test_output_is_text | 10 / 10 |
| milestone_1 → TestMilestone1 → test_output_length_reasonable | 10 / 10 |
| milestone_1 → TestMilestone1 → test_decoded_message_matches_expected_word | 10 / 10 |
| milestone_2 → TestMilestone2 → test_output_exists | 10 / 10 |
| milestone_2 → TestMilestone2 → test_output_is_text | 9 / 10 |
| milestone_2 → TestMilestone2 → test_output_length_reasonable | 9 / 10 |
| milestone_2 → TestMilestone2 → test_decoded_message_matches_expected_word | 7 / 10 |
</details>

### Analysis on Agent Failures
| Check       | Outcome  | Explanation              |
|-------------|----------|--------------------------|
| Task Instruction Sufficiency | ✅ PASS | ## Job Summary: Morse Code Decoder (C / Accelerometer)

### 1. Overall Results
| Trial | Agent | M1 Reward | M2 Reward | Overall |
|-------|-------|-----------|-----------|---------|
| tbench-task__2ZmtExf | — | 1.0 ✅ | 0.0 ❌ | **0.5** |
| tbench-task__zWF9fCa | — | 1.0 ✅ | 0.0 ❌ | **0.5** |
| tbench-task__FbgVfka | GPT-5.5 | 1.0 ✅ | 0.0 ❌ | **0.5** |

**3/3 trials scored 0.5.** Every agent aced Milestone 1 and failed Milestone 2. No agent achieved a full pass.

---

### 2. Common Failure Patterns
All three Milestone 2 failures share the **same root cause**: inadequate signal processing to separate vehicle-induced acceleration from key-strike signals.

- **2ZmtExf**: Output `S9?M?PUZZLE FAST` vs. `SOLVE THE PUZZLE FAST` — vehicle motion caused mis-classifying long Morse elements (e.g., `O` → `9?`), suggesting thresholds were slightly off.
- **zWF9fCa**: Output 100× `E` (199 chars) — every signal was classified as a dot, indicating the high-pass filter eliminated meaningful signal entirely or the detection threshold was far too low.
- **FbgVfka**: Output `ETTE E T E EET E T TT T T TT TE` — similar to zWF9fCa; the dot/dash classifier collapsed, outputting only E/T (single dot/dash) tokens, suggesting timing estimation broke under noise.

**Pattern**: All agents attempted high-pass filtering or vector-magnitude approaches, but none correctly tuned thresholds for the ±10g clipping + banking + centripetal/braking force environment. The problem appears to require more robust signal isolation than a simple high-pass filter.

---

### 3. Hack Check — Clean ✅
All three trials passed `reward_hacking` checks. No agent:
- Accessed solution directories (`/root/harbor_tasks/tbench-task/steps/milestone_*/solution/`)
- Wrote to reward files (`/logs/verifier/reward.txt`)
- Modified test files

One notable borderline behavior: both **2ZmtExf** and **zWF9fCa** reverse-engineered the reference binary (`app.out`) via `objdump`/disassembly to understand the expected algorithm. This was ruled legitimate — it was an attempt to understand the approach, not to copy a solution.

---

### 4. Debug — No Systematic Instruction Issues ✅
All three `task_specification` checks passed. The instructions provided:
- Physics parameters (2mm gap, 3–6ms down, 4–5ms up)
- Morse timing range (100–250ms dot unit)
- Vehicle dynamics (speed, turn radius, ≤15° banking, ±10g clipping)
- Output format (uppercase + spaces, 13–50 chars, single newline)

Failures were algorithmic, not due to underspecification. The task is genuinely hard: real-time embedded-style signal separation under clipping conditions.

---

### 5. Progress on Failed Trials
Agents got **meaningfully close** on M2, not stuck at zero:
- **2ZmtExf** decoded ~50–60% of characters correctly (`?PUZZLE FAST` fully correct, `SOLVE THE` mangled).
- **FbgVfka** decoded structure but lost all timing differentiation (all E/T).
- **zWF9fCa** the worst outcome — total filter collapse into repeated `E`.

Average qualitative proximity: roughly **partial credit** level — the framework and approach were sound, but parameter tuning was the final obstacle.

---

### 6. Key Differences Between Agents
Only one agent is identified (**GPT-5.5** on FbgVfka); the others are unlabeled. All three showed near-identical performance profiles, suggesting M2 is a **task-level difficulty ceiling** rather than a model-differentiation test at current capability levels. The binary reverse-engineering strategy (used by 2ZmtExf and zWF9fCa but not mentioned for FbgVfka) didn't yield a meaningful advantage — all three ended at 0.5.

---

### Recommendation
M2 success likely requires either: (a) explicit guidance on recommended filter design (e.g., adaptive thresholding on vector magnitude residuals), or (b) providing the reference algorithm parameters directly, since the current spec leaves too much tuning space for agents to converge reliably. |
<!-- test-summary-end -->